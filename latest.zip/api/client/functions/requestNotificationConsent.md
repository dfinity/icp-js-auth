---
title: requestNotificationConsent
editUrl: false
next: true
prev: true
---

> **requestNotificationConsent**(`signer`, `derivationOrigin?`): `Promise`\<[`NotificationConsentStatus`](../interfaces/NotificationConsentStatus.md)\>

Defined in: [src/client/notification-consent.ts:63](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/notification-consent.ts#L63)

Asks the user, through the identity provider, whether this application may
notify them, and registers the browser for delivery where they agree.

A refusal is an answer: it comes back as `granted: false` rather than as an
error, because the user decided and the application has something to render.

## Parameters

### signer

`Signer`

The channel to the identity provider.

### derivationOrigin?

`string`

The origin the account is derived for, where the
  application signs in under one other than its own.

## Returns

`Promise`\<[`NotificationConsentStatus`](../interfaces/NotificationConsentStatus.md)\>

What the provider recorded, read back rather than reported from the
  screen.

## Throws

Where the request asked not to render.

## Throws

Where the provider does not notify.
