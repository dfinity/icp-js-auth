---
title: requestSessionDelegation
editUrl: false
next: true
prev: true
---

> **requestSessionDelegation**(`signer`, `params`): `Promise`\<`DelegationChain`\>

Defined in: [src/client/session-delegation.ts:103](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/session-delegation.ts#L103)

Asks the identity provider for a session, and returns the chain it signed.

The chain is restricted to the Internet Identity canister, so it is not
something an application can call its own canisters with. It is what app
delegations are minted from.

## Parameters

### signer

`Signer`

### params

`SessionDelegationParams` \| `Promise`\<`SessionDelegationParams`\>

## Returns

`Promise`\<`DelegationChain`\>
