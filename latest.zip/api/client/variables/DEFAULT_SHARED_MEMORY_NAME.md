---
title: DEFAULT_SHARED_MEMORY_NAME
editUrl: false
next: true
prev: true
---

> `const` **DEFAULT\_SHARED\_MEMORY\_NAME**: `"ic-credentials"` = `'ic-credentials'`

Defined in: [src/client/shared-memory-credential-storage.ts:5](https://github.com/dfinity/icp-js-auth/blob/8a502944aa4ccf5492dd317604ff58c11453b1d1/src/client/shared-memory-credential-storage.ts#L5)

The channel and lock prefix every instance agrees on by default.
