---
title: DB_VERSION
editUrl: false
next: true
prev: true
---

> `const` **DB\_VERSION**: `1` = `1`

Defined in: [src/client/db.ts:4](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/db.ts#L4)
