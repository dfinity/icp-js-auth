---
title: DB_VERSION
editUrl: false
next: true
prev: true
---

> `const` **DB\_VERSION**: `1` = `1`

Defined in: [src/client/db.ts:4](https://github.com/dfinity/icp-js-auth/blob/8a502944aa4ccf5492dd317604ff58c11453b1d1/src/client/db.ts#L4)
