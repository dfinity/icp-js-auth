---
title: AuthClientCreateOptions
editUrl: false
next: true
prev: true
---

> **AuthClientCreateOptions** = [`AuthClientBaseOptions`](../interfaces/AuthClientBaseOptions.md) & (\{ `openIdProvider?`: [`OpenIdProvider`](OpenIdProvider.md); `ssoDomain?`: `never`; \} \| \{ `openIdProvider?`: `never`; `ssoDomain?`: `string`; \})

Defined in: [src/client/auth-client.ts:239](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/auth-client.ts#L239)

Options for creating an [AuthClient](../classes/AuthClient.md).

At most one one-click sign-in entry point may be set: `openIdProvider` for a
hardcoded provider, or `ssoDomain` for an organization's own SSO.
