---
title: SessionStatus
editUrl: false
next: true
prev: true
---

> **SessionStatus** = \{ `expiresAtMs`: `number`; `principal`: `Principal`; `state`: `"signed-in"`; \} \| \{ `expiresAtMs`: `number`; `principal`: `Principal`; `state`: `"signed-in-elsewhere"`; \} \| \{ `expiresAtMs`: `number`; `principal`: `Principal`; `state`: `"expired"`; \} \| \{ `state`: `"signed-out"`; \}

Defined in: [src/client/auth-client.ts:324](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/auth-client.ts#L324)

Who is signed in for this origin, and until when.

`principal` and `expiresAtMs` are present in every case where a record
exists, so an application can name the account and count down to the end of a
sign-in without reading the store itself.

## Union Members

### Type Literal

\{ `expiresAtMs`: `number`; `principal`: `Principal`; `state`: `"signed-in"`; \}

***

### Type Literal

\{ `expiresAtMs`: `number`; `principal`: `Principal`; `state`: `"signed-in-elsewhere"`; \}

Someone is signed in on this domain, but this origin holds no credential
for them, so it cannot act yet. Acquire one silently, or ask the user.

***

### Type Literal

\{ `expiresAtMs`: `number`; `principal`: `Principal`; `state`: `"expired"`; \}

***

### Type Literal

\{ `state`: `"signed-out"`; \}
