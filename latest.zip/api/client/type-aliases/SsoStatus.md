---
title: SsoStatus
editUrl: false
next: true
prev: true
---

> **SsoStatus** = \{ `state`: `"checking"`; \} \| \{ `name?`: `string`; `state`: `"available"`; \} \| \{ `reason`: `string`; `state`: `"invalid"`; \} \| \{ `reason?`: `string`; `retryAfter?`: `Date`; `state`: `"unavailable"`; \}

Defined in: [src/client/sso-status.ts:20](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/sso-status.ts#L20)

Whether the organization domain a client was built with can be signed in with.

- `checking`: Internet Identity has not answered yet.
- `available`: the domain resolves to a usable SSO configuration. `name` is
  the label the organization publishes, for a "Continue with Acme" button.
- `invalid`: the value is not a domain, so no check is made and a retry
  cannot help. The user has to change what they typed. `reason` names every
  problem with it, to show as is.
- `unavailable`: the domain publishes no usable configuration, or fetching
  it is failing. While `retryAfter` is in the future Internet Identity will
  not fetch again, so a retry before then gets the same answer; without it,
  a retry cannot help. `reason` is Internet Identity's explanation, when it
  gives one, to show as is.
