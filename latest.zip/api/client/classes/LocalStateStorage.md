---
title: LocalStateStorage
editUrl: false
next: true
prev: true
---

Defined in: [src/client/state/local-state-storage.ts:38](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/local-state-storage.ts#L38)

State in `localStorage`, so every tab of an origin agrees on it and it
survives a reload.

Workers cannot read `localStorage`, so a tab mirrors each record it writes or
subscribes to into IndexedDB and announces it, and a worker loads the mirror
into memory. A worker changes nothing: signing in and out happens in a page.

The two fields are written as `<principal>|<expiration>` rather than JSON,
because an expiration is a `bigint` and JSON has no way to carry one.

## See

implements [StateStorage](../interfaces/StateStorage.md)

## Implements

- [`StateStorage`](../interfaces/StateStorage.md)

## Constructors

### Constructor

> **new LocalStateStorage**(): `LocalStateStorage`

#### Returns

`LocalStateStorage`

## Properties

### isReadOnly

> `readonly` **isReadOnly**: `boolean`

Defined in: [src/client/state/local-state-storage.ts:45](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/local-state-storage.ts#L45)

True in a worker, which reads what its tabs mirror and changes nothing.

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`isReadOnly`](../interfaces/StateStorage.md#isreadonly)

## Methods

### discard()

> **discard**(`key`): `void`

Defined in: [src/client/state/local-state-storage.ts:95](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/local-state-storage.ts#L95)

The same as [remove](#remove): this store publishes nothing beyond the origin.

#### Parameters

##### key

`string`

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`discard`](../interfaces/StateStorage.md#discard)

***

### get()

> **get**(`key`): [`SessionState`](../interfaces/SessionState.md) \| `null`

Defined in: [src/client/state/local-state-storage.ts:61](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/local-state-storage.ts#L61)

The state, or `null` where nothing is signed in within this store's reach.

#### Parameters

##### key

`string`

#### Returns

[`SessionState`](../interfaces/SessionState.md) \| `null`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`get`](../interfaces/StateStorage.md#get)

***

### ready()

> **ready**(): `Promise`\<`void`\>

Defined in: [src/client/state/local-state-storage.ts:53](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/local-state-storage.ts#L53)

Resolves once a worker has loaded the keys subscribed to so far, and every load queued meanwhile.

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`ready`](../interfaces/StateStorage.md#ready)

***

### remove()

> **remove**(`key`): `void`

Defined in: [src/client/state/local-state-storage.ts:87](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/local-state-storage.ts#L87)

Removes the state, and anything this store publishes beyond this origin.

What signing out does: the user ended the sign-in, so a sibling reading a
shared record must stop seeing one.

#### Parameters

##### key

`string`

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`remove`](../interfaces/StateStorage.md#remove)

***

### set()

> **set**(`key`, `state`): `void`

Defined in: [src/client/state/local-state-storage.ts:80](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/local-state-storage.ts#L80)

#### Parameters

##### key

`string`

##### state

`Omit`\<[`SessionState`](../interfaces/SessionState.md), `"held"`\>

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`set`](../interfaces/StateStorage.md#set)

***

### subscribe()

> **subscribe**(`key`, `listener`): () => `void`

Defined in: [src/client/state/local-state-storage.ts:107](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/local-state-storage.ts#L107)

Fires when the state changes, here or in another tab of this origin.

`localStorage` raises `storage` in every tab except the one that wrote, so
that event carries a change between tabs and a same-tab write is announced
directly. Either way the record is readable before it is announced, so a
listener asking who is signed in sees what it was told about.

#### Parameters

##### key

`string`

##### listener

() => `void`

#### Returns

() => `void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`subscribe`](../interfaces/StateStorage.md#subscribe)
