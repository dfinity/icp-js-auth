---
title: AuthClient
editUrl: false
next: true
prev: true
---

Defined in: [src/client/auth-client.ts:361](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L361)

## Constructors

### Constructor

> **new AuthClient**(`options?`): `AuthClient`

Defined in: [src/client/auth-client.ts:400](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L400)

#### Parameters

##### options?

[`AuthClientCreateOptions`](../type-aliases/AuthClientCreateOptions.md) = `{}`

#### Returns

`AuthClient`

## Methods

### dispose()

> **dispose**(): `void`

Defined in: [src/client/auth-client.ts:746](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L746)

Releases what this client hooked: the browser listeners, the state
subscription, the refresh the identity has scheduled, and an SSO domain
check still in progress. Call it when discarding a client, so nothing it
registered outlives it.

#### Returns

`void`

***

### getIdentity()

> **getIdentity**(): `Promise`\<`Identity`\>

Defined in: [src/client/auth-client.ts:565](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L565)

Returns the current identity, restoring a previous session if available.

#### Returns

`Promise`\<`Identity`\>

***

### getPrincipal()

> **getPrincipal**(): `Principal` \| `undefined`

Defined in: [src/client/auth-client.ts:626](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L626)

Who this origin can act as, or `undefined` where it cannot act.

The same question [isAuthenticated](#isauthenticated) answers, returning who rather than
whether — so the two never disagree. Synchronous, and read from the state
rather than from whatever material happens to be held, so a page renders on
it without opening a store and without waiting for a mint. That is the
difference from `(await getIdentity()).getPrincipal()`, which is asynchronous
and, on a load with no delegation worth adopting, waits for one to be minted.

A principal here means calls made as it will be accepted, so an expired
record answers `undefined` even though it still names an account, and so does
a record naming an account this origin holds nothing for. Returning one
anyway would have an application acting on a session that has ended: the
check most reach for is `if (getPrincipal())`, and it has to mean what it
looks like it means.

[getStatus](#getstatus) is where those cases are readable, and it carries the
account principal in each of them — so nothing is lost by this being narrow,
and an application wanting to say whose session ended asks there.

#### Returns

`Principal` \| `undefined`

***

### getSsoStatus()

> **getSsoStatus**(): [`SsoStatus`](../type-aliases/SsoStatus.md) \| `undefined`

Defined in: [src/client/auth-client.ts:676](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L676)

Whether the organization domain this client was built with can be signed
in with, or `undefined` for a client built without `ssoDomain`.

Synchronous, and the same object until the answer changes, like
[getStatus](#getstatus); [subscribe](#subscribe) says when to read it again. A client
built with `ssoDomain` starts checking as soon as it is built: it asks
Internet Identity to resolve the domain, then reads the result
until it is final, so `checking` lasts until Internet Identity answers.
Building the client also warms Internet Identity's cache for the domain, so
a sign-in that follows starts without waiting on the fetch.

[signIn](#signin) proceeds in every state: Internet Identity resolves the
domain itself during the sign-in, and explains a failure, a value that is
not a domain included, on its own screen.

#### Returns

[`SsoStatus`](../type-aliases/SsoStatus.md) \| `undefined`

#### Example

```ts
const client = new AuthClient({ ssoDomain: input.value });
client.subscribe(() => render(client.getSsoStatus()));
render(client.getSsoStatus());
```

***

### getStatus()

> **getStatus**(): [`SessionStatus`](../type-aliases/SessionStatus.md)

Defined in: [src/client/auth-client.ts:636](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L636)

Who is signed in for this origin right now.

Synchronous, so a page can render on it without opening a store.

#### Returns

[`SessionStatus`](../type-aliases/SessionStatus.md)

***

### isAuthenticated()

> **isAuthenticated**(): `boolean`

Defined in: [src/client/auth-client.ts:601](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L601)

Checks whether the user has an active, non-expired session.

#### Returns

`boolean`

***

### memoize()

#### Call Signature

> **memoize**\<`T`\>(`produce`): `Promise`\<`T`\>

Defined in: [src/client/auth-client.ts:1230](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L1230)

Runs and journals a piece of your own async work so its result stays stable
across the `'redirect'` flow.

In `'redirect'` mode the page unloads on each step and `signIn` /
`requestAttributes` re-run on the return load, so a value you compute on the
first visit (from `location`, a fetch, `crypto`, …) would otherwise be
recomputed — and may differ — on the return. Wrap it in `memoize`: it runs
`produce` once on the first visit, journals the result, and replays that
result on the return load instead of re-running. Use it for a value the
post-flow code depends on, e.g. the URL to navigate to once sign-in
completes:

```ts
const next = await authClient.memoize(
  () => new URLSearchParams(location.search).get('next') ?? '/',
);
await authClient.signIn();
location.assign(next); // the value captured before the redirect
```

Call `memoize` in a stable order relative to `signIn` / `requestAttributes`
across loads (same order every load — branch only on values recovered from
earlier results), and keep the result JSON-serializable, since the journal
is JSON.

In `'window'` mode there is no redirect, so this simply runs `produce` and
returns its result without persisting anything.

Mirrors the producer's shape: a synchronous `produce` returns its value
directly, an asynchronous one returns a promise. Awaiting the result is
always safe (`await` on a non-promise is a no-op); the synchronous form lets
a value be memoized where an `await` is not possible, such as in a
constructor.

##### Type Parameters

###### T

`T`

##### Parameters

###### produce

() => `Promise`\<`T`\>

Produces the value to journal on the first load.

##### Returns

`Promise`\<`T`\>

The produced value, or the journaled value on a replay load.

#### Call Signature

> **memoize**\<`T`\>(`produce`): `T`

Defined in: [src/client/auth-client.ts:1231](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L1231)

Runs and journals a piece of your own async work so its result stays stable
across the `'redirect'` flow.

In `'redirect'` mode the page unloads on each step and `signIn` /
`requestAttributes` re-run on the return load, so a value you compute on the
first visit (from `location`, a fetch, `crypto`, …) would otherwise be
recomputed — and may differ — on the return. Wrap it in `memoize`: it runs
`produce` once on the first visit, journals the result, and replays that
result on the return load instead of re-running. Use it for a value the
post-flow code depends on, e.g. the URL to navigate to once sign-in
completes:

```ts
const next = await authClient.memoize(
  () => new URLSearchParams(location.search).get('next') ?? '/',
);
await authClient.signIn();
location.assign(next); // the value captured before the redirect
```

Call `memoize` in a stable order relative to `signIn` / `requestAttributes`
across loads (same order every load — branch only on values recovered from
earlier results), and keep the result JSON-serializable, since the journal
is JSON.

In `'window'` mode there is no redirect, so this simply runs `produce` and
returns its result without persisting anything.

Mirrors the producer's shape: a synchronous `produce` returns its value
directly, an asynchronous one returns a promise. Awaiting the result is
always safe (`await` on a non-promise is a no-op); the synchronous form lets
a value be memoized where an `await` is not possible, such as in a
constructor.

##### Type Parameters

###### T

`T`

##### Parameters

###### produce

() => `T`

Produces the value to journal on the first load.

##### Returns

`T`

The produced value, or the journaled value on a replay load.

***

### refreshSsoStatus()

> **refreshSsoStatus**(): `void`

Defined in: [src/client/auth-client.ts:690](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L690)

Checks the organization domain again, for a "Try again" button.

The status goes back to `checking` and then to the new answer. Calling it
while an `unavailable` answer's `retryAfter` is still in the future is
harmless: Internet Identity does not fetch again before then, so the answer
comes back the same at once. Nothing re-checks on its own once `retryAfter`
passes. Does nothing for an `invalid` domain, which no retry can fix, or for
a client built without `ssoDomain`.

#### Returns

`void`

***

### requestAttributes()

> **requestAttributes**(`params`): `Promise`\<[`SignedAttributes`](../interfaces/SignedAttributes.md)\>

Defined in: [src/client/auth-client.ts:1134](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L1134)

Requests signed identity attributes from the identity provider.

The `nonce` is a callback that produces the 32-byte nonce (typically
fetched from the RP canister), returning a promise resolving to it. It is a
callback rather than a value so the redirect flow can journal the nonce and
reuse the exact same bytes when the flow replays on the return load,
instead of fetching a fresh single-use nonce that the signer never signed
against.

In 'window' mode the callback lets the identity provider window open while the
nonce is still resolving, avoiding a perceived delay before the user sees
the prompt; the signer keeps the channel open while the request waits for
its nonce. In both modes the request takes its place with the signer when
this method is called, so it can be issued alongside `signIn` in either
order.

#### Parameters

##### params

Request parameters.

###### keys

`string`[]

Attribute keys to request (e.g. `['email', 'name']`).

###### nonce

() => `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Produces the 32-byte nonce issued by the RP canister,
  as a promise resolving to it.

#### Returns

`Promise`\<[`SignedAttributes`](../interfaces/SignedAttributes.md)\>

Signed attribute data and signature.

#### Throws

When the identity provider returns an error or an invalid response.

***

### signIn()

> **signIn**(`options?`): `Promise`\<`Identity`\>

Defined in: [src/client/auth-client.ts:871](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L871)

#### Parameters

##### options?

[`AuthClientSignInOptions`](../interfaces/AuthClientSignInOptions.md)

#### Returns

`Promise`\<`Identity`\>

***

### signOut()

> **signOut**(`options?`): `Promise`\<`void`\>

Defined in: [src/client/auth-client.ts:1245](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L1245)

Clears the stored session and resets the client to an anonymous state.

#### Parameters

##### options?

Sign-out options.

###### returnTo?

`string`

URL to navigate to after sign-out.

#### Returns

`Promise`\<`void`\>

***

### subscribe()

> **subscribe**(`listener`): () => `void`

Defined in: [src/client/auth-client.ts:730](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L730)

Watches who is signed in here, and the SSO status of a client built with
`ssoDomain`, and returns a function that stops watching.

`getStatus()`, `getSsoStatus()` and the predicates beside them are
snapshots, so an application rendering on them needs to be told when to read
again. The record changes for reasons that are nothing to do with this
client: another tab signing out, a sibling subdomain publishing a sign-in,
a peer client on this page re-issuing silently. The SSO status changes when
Internet Identity answers. This is how both arrive.

Fired once the new answer is readable, so a listener sees what it was told
about. It says that something changed and not what: a listener reads the
answer it wants, `getStatus()` or `getSsoStatus()`.

What it does not cover is the identity being replaced under an application
that holds one — an app delegation rotating is deliberately invisible, and
nothing about who is signed in has changed when it does.

#### Parameters

##### listener

() => `void`

Called after the record or the SSO status changes.

#### Returns

A function that unregisters it.

() => `void`
