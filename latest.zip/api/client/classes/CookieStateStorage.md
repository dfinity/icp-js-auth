---
title: CookieStateStorage
editUrl: false
next: true
prev: true
---

Defined in: [src/client/state/cookie-state-storage.ts:59](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/cookie-state-storage.ts#L59)

The state of a sign-in, in a cookie, so every sibling of a domain shares it.

A cookie is the only thing that crosses between origins, which is what lets one
sign-out end them all: the record is the domain's rather than this origin's, so
removing it is what tells a sibling the sign-in is over. It carries no chain
and no key, so a sibling acting on it asks the identity provider to re-issue
rather than treating it as proof.

Workers cannot read cookies, and only ever act with this origin's own
credentials, so a worker reads this origin's claim, which the
[LocalStateStorage](LocalStateStorage.md) below mirrors to it. A sign-in this origin holds no
credentials for reads as signed out there. A worker only reads: signing in and
out happens in a page.

## See

implements [StateStorage](../interfaces/StateStorage.md)

## Implements

- [`StateStorage`](../interfaces/StateStorage.md)

## Constructors

### Constructor

> **new CookieStateStorage**(`options`): `CookieStateStorage`

Defined in: [src/client/state/cookie-state-storage.ts:90](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/cookie-state-storage.ts#L90)

#### Parameters

##### options

[`CookieStateStorageOptions`](../interfaces/CookieStateStorageOptions.md)

#### Returns

`CookieStateStorage`

## Properties

### resumable

> `readonly` **resumable**: `true` = `true`

Defined in: [src/client/state/cookie-state-storage.ts:69](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/cookie-state-storage.ts#L69)

A sign-in kept here may be resumed without a ceremony.

This is the store whose record reaches past one origin, so it is the store
whose siblings arrive holding no credential and needing the identity
provider to remember the session they can be given one from. Asking a
provider to keep a sign-in is only worth the persistence where somebody is
going to come back to it, and here somebody will.

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`resumable`](../interfaces/StateStorage.md#resumable)

## Accessors

### isReadOnly

#### Get Signature

> **get** **isReadOnly**(): `boolean`

Defined in: [src/client/state/cookie-state-storage.ts:81](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/cookie-state-storage.ts#L81)

True in a worker, which reads this origin's claim and changes nothing.

##### Returns

`boolean`

Whether this store only reads the state here, as a store does in a worker.
The client then changes nothing: it cannot sign in or out, and a session it
finds unusable is left for a page of this origin to end.

Absent means false.

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`isReadOnly`](../interfaces/StateStorage.md#isreadonly)

## Methods

### discard()

> **discard**(`key`): `void`

Defined in: [src/client/state/cookie-state-storage.ts:204](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/cookie-state-storage.ts#L204)

Drops this origin's claim on the sign-in, leaving the cookie for the siblings.

An origin whose chain turns out to be dead cannot tell a revoked session from
one a sibling replaced by signing in, and in the second case that sibling
wrote this cookie a moment ago. So the record stands and this origin reads it
as not held, which is what sends it to acquire one of its own.

#### Parameters

##### key

`string`

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`discard`](../interfaces/StateStorage.md#discard)

***

### get()

> **get**(`key`): [`SessionState`](../interfaces/SessionState.md) \| `null`

Defined in: [src/client/state/cookie-state-storage.ts:152](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/cookie-state-storage.ts#L152)

The state, or `null` where nothing is signed in within this store's reach.

#### Parameters

##### key

`string`

#### Returns

[`SessionState`](../interfaces/SessionState.md) \| `null`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`get`](../interfaces/StateStorage.md#get)

***

### ready()

> **ready**(): `Promise`\<`void`\>

Defined in: [src/client/state/cookie-state-storage.ts:86](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/cookie-state-storage.ts#L86)

Resolves once a worker has loaded this origin's claim.

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`ready`](../interfaces/StateStorage.md#ready)

***

### remove()

> **remove**(`key`): `void`

Defined in: [src/client/state/cookie-state-storage.ts:189](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/cookie-state-storage.ts#L189)

Removes the state, and anything this store publishes beyond this origin.

What signing out does: the user ended the sign-in, so a sibling reading a
shared record must stop seeing one.

#### Parameters

##### key

`string`

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`remove`](../interfaces/StateStorage.md#remove)

***

### set()

> **set**(`key`, `state`): `void`

Defined in: [src/client/state/cookie-state-storage.ts:180](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/cookie-state-storage.ts#L180)

#### Parameters

##### key

`string`

##### state

`Omit`\<[`SessionState`](../interfaces/SessionState.md), `"held"`\>

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`set`](../interfaces/StateStorage.md#set)

***

### subscribe()

> **subscribe**(`key`, `listener`): () => `void`

Defined in: [src/client/state/cookie-state-storage.ts:218](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/cookie-state-storage.ts#L218)

Fires when the state changes, including when a sibling subdomain changes it.

`document.cookie` raises no event and no `BroadcastChannel` crosses origins,
so a sibling's sign-out is visible only by looking: the Cookie Store API
where the browser has it, and otherwise a re-check whenever this page is
shown or its window regains focus, which is when the user is about to act on
the answer.

#### Parameters

##### key

`string`

##### listener

() => `void`

#### Returns

() => `void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`subscribe`](../interfaces/StateStorage.md#subscribe)
