---
title: MemoryStateStorage
editUrl: false
next: true
prev: true
---

Defined in: [src/client/state/memory-state-storage.ts:10](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/memory-state-storage.ts#L10)

State held for the lifetime of the instance and shared with nothing.

For tests, and for a client that should share its sign-in with nothing: a
reload starts from nothing.

## See

implements [StateStorage](../interfaces/StateStorage.md)

## Implements

- [`StateStorage`](../interfaces/StateStorage.md)

## Constructors

### Constructor

> **new MemoryStateStorage**(): `MemoryStateStorage`

#### Returns

`MemoryStateStorage`

## Methods

### discard()

> **discard**(`key`): `void`

Defined in: [src/client/state/memory-state-storage.ts:31](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/memory-state-storage.ts#L31)

The same as [remove](#remove): this store publishes nothing at all.

#### Parameters

##### key

`string`

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`discard`](../interfaces/StateStorage.md#discard)

***

### get()

> **get**(`key`): [`SessionState`](../interfaces/SessionState.md) \| `null`

Defined in: [src/client/state/memory-state-storage.ts:14](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/memory-state-storage.ts#L14)

The state, or `null` where nothing is signed in within this store's reach.

#### Parameters

##### key

`string`

#### Returns

[`SessionState`](../interfaces/SessionState.md) \| `null`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`get`](../interfaces/StateStorage.md#get)

***

### remove()

> **remove**(`key`): `void`

Defined in: [src/client/state/memory-state-storage.ts:25](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/memory-state-storage.ts#L25)

Removes the state, and anything this store publishes beyond this origin.

What signing out does: the user ended the sign-in, so a sibling reading a
shared record must stop seeing one.

#### Parameters

##### key

`string`

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`remove`](../interfaces/StateStorage.md#remove)

***

### set()

> **set**(`key`, `state`): `void`

Defined in: [src/client/state/memory-state-storage.ts:20](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/memory-state-storage.ts#L20)

#### Parameters

##### key

`string`

##### state

`Omit`\<[`SessionState`](../interfaces/SessionState.md), `"held"`\>

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`set`](../interfaces/StateStorage.md#set)

***

### subscribe()

> **subscribe**(`key`, `listener`): () => `void`

Defined in: [src/client/state/memory-state-storage.ts:45](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/memory-state-storage.ts#L45)

Fires when the state changes, which here means when something writes to
this instance.

Nothing outside the process can reach a `Map`, so a medium is not what makes
this worth having: two clients can be handed the same instance, and this is
how the one that did not write finds out. Each listener is told only when the
record actually changed since it was last told, so a client's own writes do
not come back to it as news.

#### Parameters

##### key

`string`

##### listener

() => `void`

#### Returns

() => `void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`subscribe`](../interfaces/StateStorage.md#subscribe)
