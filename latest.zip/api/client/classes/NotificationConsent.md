---
title: NotificationConsent
editUrl: false
next: true
prev: true
---

Defined in: [src/client/notification-consent.ts:158](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/notification-consent.ts#L158)

Reads and withdraws an application's consent, at the Internet Identity canister.

## Methods

### revoke()

> **revoke**(): `Promise`\<`void`\>

Defined in: [src/client/notification-consent.ts:208](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/notification-consent.ts#L208)

Withdraws this application's consent to notify the signed-in user.

Idempotent at the canister: consent that is already withdrawn is `Ok`, because
the caller wanted it gone and it is gone. What comes back as an error is the
canister failing to write, and it is raised rather than dropped — an
application that told a user it had turned notifications off should be able to
find out that it had not.

#### Returns

`Promise`\<`void`\>

***

### status()

> **status**(): `Promise`\<[`NotificationConsentStatus`](../interfaces/NotificationConsentStatus.md)\>

Defined in: [src/client/notification-consent.ts:191](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/notification-consent.ts#L191)

Whether this application may notify the signed-in user.

A query, so the answer is uncertified: it is what a control is painted from,
not something to rest a decision on.

#### Returns

`Promise`\<[`NotificationConsentStatus`](../interfaces/NotificationConsentStatus.md)\>

***

### create()

> `static` **create**(`options`): `Promise`\<`NotificationConsent`\>

Defined in: [src/client/notification-consent.ts:172](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/notification-consent.ts#L172)

Builds the calls as the session.

As the session and not as the application: Internet Identity authorises both
methods by the principal the session signs with, which is the one that mints
app delegations rather than any of the ones minted from it.

#### Parameters

##### options

[`NotificationConsentOptions`](../interfaces/NotificationConsentOptions.md)

#### Returns

`Promise`\<`NotificationConsent`\>
