---
title: SessionGoneError
editUrl: false
next: true
prev: true
---

Defined in: [src/client/session/app-delegation-source.ts:12](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/session/app-delegation-source.ts#L12)

Thrown when the canister has no session behind the caller: revoked, expired,
pruned, or never one at all.

This is the one terminal outcome. Everything else a mint can fail with, a
transport error or an internal canister error, leaves the session alone and is
worth retrying, so only this type may end a session.

## Extends

- `Error`

## Constructors

### Constructor

> **new SessionGoneError**(`message?`): `SessionGoneError`

Defined in: [src/client/session/app-delegation-source.ts:13](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/session/app-delegation-source.ts#L13)

#### Parameters

##### message?

`string` = `'The session behind this identity no longer exists'`

#### Returns

`SessionGoneError`

#### Overrides

`Error.constructor`

## Properties

### cause?

> `optional` **cause?**: `unknown`

Defined in: node\_modules/.pnpm/typescript@6.0.3/node\_modules/typescript/lib/lib.es2022.error.d.ts:24

#### Inherited from

`Error.cause`

***

### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@6.0.3/node\_modules/typescript/lib/lib.es5.d.ts:1075

#### Inherited from

`Error.message`

***

### name

> **name**: `string`

Defined in: node\_modules/.pnpm/typescript@6.0.3/node\_modules/typescript/lib/lib.es5.d.ts:1074

#### Inherited from

`Error.name`

***

### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@6.0.3/node\_modules/typescript/lib/lib.es5.d.ts:1076

#### Inherited from

`Error.stack`
