---
title: SessionNotHeldError
editUrl: false
next: true
prev: true
---

Defined in: [src/client/auth-client.ts:324](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L324)

Thrown when a sign-in exists within the state store's reach but this origin
holds no credential for it.

A sibling subdomain reads the shared record on its first load and is in exactly
this position: someone is signed in, and it has nothing to act with until it
acquires its own. Catching this is where a silent re-issue belongs.

## Extends

- `Error`

## Constructors

### Constructor

> **new SessionNotHeldError**(`message?`): `SessionNotHeldError`

Defined in: [src/client/auth-client.ts:325](https://github.com/dfinity/icp-js-auth/blob/4cdcf6d97a833c0e41e86a5836195549a4cc9542/src/client/auth-client.ts#L325)

#### Parameters

##### message?

`string` = `'A sign-in exists for this domain, but this origin holds no credential for it'`

#### Returns

`SessionNotHeldError`

#### Overrides

`Error.constructor`

## Properties

### cause?

> `optional` **cause?**: `unknown`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2022.error.d.ts:26

#### Inherited from

`Error.cause`

***

### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

#### Inherited from

`Error.message`

***

### name

> **name**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1076

#### Inherited from

`Error.name`

***

### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

#### Inherited from

`Error.stack`
