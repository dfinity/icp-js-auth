---
title: SignedAttributes
editUrl: false
next: true
prev: true
---

Defined in: [src/client/auth-client.ts:274](https://github.com/dfinity/icp-js-auth/blob/8a502944aa4ccf5492dd317604ff58c11453b1d1/src/client/auth-client.ts#L274)

## Properties

### data

> **data**: `Uint8Array`

Defined in: [src/client/auth-client.ts:275](https://github.com/dfinity/icp-js-auth/blob/8a502944aa4ccf5492dd317604ff58c11453b1d1/src/client/auth-client.ts#L275)

***

### signature

> **signature**: `Uint8Array`

Defined in: [src/client/auth-client.ts:276](https://github.com/dfinity/icp-js-auth/blob/8a502944aa4ccf5492dd317604ff58c11453b1d1/src/client/auth-client.ts#L276)
