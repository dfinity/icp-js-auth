---
title: SignedAttributes
editUrl: false
next: true
prev: true
---

Defined in: [src/client/auth-client.ts:302](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/auth-client.ts#L302)

## Properties

### data

> **data**: `Uint8Array`

Defined in: [src/client/auth-client.ts:303](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/auth-client.ts#L303)

***

### signature

> **signature**: `Uint8Array`

Defined in: [src/client/auth-client.ts:304](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/auth-client.ts#L304)
