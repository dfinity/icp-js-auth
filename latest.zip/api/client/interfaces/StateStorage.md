---
title: StateStorage
editUrl: false
next: true
prev: true
---

Defined in: [src/client/state/state-storage.ts:40](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/state-storage.ts#L40)

Holds the state of a sign-in.

This is what decides whether this origin is signed in and as whom. It is a
store of its own because it has to be readable without awaiting, which a
credential store does not.

A record can be stale — a session revoked at the canister still reads as
signed in until something calls and is refused — so it is the state as this
browser knows it rather than an authority against the network.

## Properties

### isReadOnly?

> `readonly` `optional` **isReadOnly?**: `boolean`

Defined in: [src/client/state/state-storage.ts:101](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/state-storage.ts#L101)

Whether this store only reads the state here, as a store does in a worker.
The client then changes nothing: it cannot sign in or out, and a session it
finds unusable is left for a page of this origin to end.

Absent means false.

***

### resumable?

> `readonly` `optional` **resumable?**: `boolean`

Defined in: [src/client/state/state-storage.ts:81](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/state-storage.ts#L81)

Whether a sign-in kept in this store may be resumed without a ceremony.

True only where the record reaches past this origin, because that is the
case a silent re-issue exists for: a sibling reads the sign-in, holds no
credential of its own, and needs the identity provider to remember the
session it can extend. A store the origin keeps to itself has nothing to
gain and would only be asking the provider to persist a sign-in on a device
where nothing wanted one kept.

Absent means false, which is the answer for a store that never considered
the question.

## Methods

### discard()

> **discard**(`key`): `void`

Defined in: [src/client/state/state-storage.ts:66](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/state-storage.ts#L66)

Removes what this origin holds, leaving anything shared alone.

What finding out does, which is a different act. An origin whose chain turns
out to be dead cannot tell whether the session was revoked or replaced by a
sibling signing in — and in the second case the shared record was written by
that sibling a moment ago, so retracting it would tell it that the session it
just obtained is gone.

A store that publishes nothing beyond this origin answers it with
[remove](#remove), which is one line and the right answer.

#### Parameters

##### key

`string`

#### Returns

`void`

***

### get()

> **get**(`key`): [`SessionState`](SessionState.md) \| `null`

Defined in: [src/client/state/state-storage.ts:42](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/state-storage.ts#L42)

The state, or `null` where nothing is signed in within this store's reach.

#### Parameters

##### key

`string`

#### Returns

[`SessionState`](SessionState.md) \| `null`

***

### ready()?

> `optional` **ready**(): `Promise`\<`void`\>

Defined in: [src/client/state/state-storage.ts:111](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/state-storage.ts#L111)

Resolves once [get](#get) answers with the stored state, for a store that
loads it asynchronously. The client waits for it before restoring a session:
a store still loading reads as signed out, and restoring from that would end
the session.

Absent means the store is ready from the start.

#### Returns

`Promise`\<`void`\>

***

### remove()

> **remove**(`key`): `void`

Defined in: [src/client/state/state-storage.ts:52](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/state-storage.ts#L52)

Removes the state, and anything this store publishes beyond this origin.

What signing out does: the user ended the sign-in, so a sibling reading a
shared record must stop seeing one.

#### Parameters

##### key

`string`

#### Returns

`void`

***

### set()

> **set**(`key`, `state`): `void`

Defined in: [src/client/state/state-storage.ts:44](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/state-storage.ts#L44)

#### Parameters

##### key

`string`

##### state

`Omit`\<[`SessionState`](SessionState.md), `"held"`\>

#### Returns

`void`

***

### subscribe()

> **subscribe**(`key`, `listener`): () => `void`

Defined in: [src/client/state/state-storage.ts:92](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/state-storage.ts#L92)

Registers a listener fired when the state under `key` changes, including
when something other than this client changed it. Returns a function that
unregisters it.

Required rather than optional: two clients can share one store, even a
store with no medium behind it, and a client that cannot be told the record
changed under it goes on answering for a sign-in that is no longer there.

#### Parameters

##### key

`string`

##### listener

() => `void`

#### Returns

() => `void`
