---
title: SessionState
editUrl: false
next: true
prev: true
---

Defined in: [src/client/state/state-storage.ts:11](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/state-storage.ts#L11)

What a client knows about its sign-in without holding a credential: which
account is signed in here, and when that ends.

Both fields are public. The principal is what an application's canisters see
as the caller, and the expiration is what the identity provider granted, so
neither is a secret and both can live somewhere a page reads synchronously.

## Properties

### expiration

> **expiration**: `bigint`

Defined in: [src/client/state/state-storage.ts:15](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/state-storage.ts#L15)

Nanoseconds since the epoch, matching `Delegation.expiration`.

***

### held

> **held**: `boolean`

Defined in: [src/client/state/state-storage.ts:26](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/state-storage.ts#L26)

Whether this origin holds a credential for that account, or only knows the
sign-in exists.

Derived on read and never published: where the record reaches further than
one origin, the record itself cannot carry a per-origin fact. A sibling
subdomain that has not acquired its own credential reads the sign-in with
`held: false`, which is what tells it to acquire one.

***

### principal

> **principal**: `Principal`

Defined in: [src/client/state/state-storage.ts:12](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/state-storage.ts#L12)
