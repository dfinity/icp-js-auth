---
title: AppDelegationSource
editUrl: false
next: true
prev: true
---

Defined in: [src/client/session/app-delegation-source.ts:56](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/session/app-delegation-source.ts#L56)

Where [SessionIdentity](../classes/SessionIdentity.md) gets an app delegation from.

The identity decides *when* to mint; this decides *how*. Splitting them is
what lets the timing be tested without a replica, and what keeps the identity
free of any agent or canister id.

## Methods

### mint()

> **mint**(`appPublicKey`): `Promise`\<`DelegationChain`\>

Defined in: [src/client/session/app-delegation-source.ts:65](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/session/app-delegation-source.ts#L65)

Mint a delegation from the session to `appPublicKey`.

Three outcomes. [SessionGoneError](../classes/SessionGoneError.md) where the session no longer
exists, SessionUnsupportedError where it exists but this library
cannot act for it, and anything else where the attempt may be worth
repeating.

#### Parameters

##### appPublicKey

`DerEncodedPublicKey`

#### Returns

`Promise`\<`DelegationChain`\>
