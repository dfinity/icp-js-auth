---
title: CookieStateStorageOptions
editUrl: false
next: true
prev: true
---

Defined in: [src/client/state/cookie-state-storage.ts:30](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/cookie-state-storage.ts#L30)

## Properties

### domain

> **domain**: `string`

Defined in: [src/client/state/cookie-state-storage.ts:40](https://github.com/dfinity/icp-js-auth/blob/bb45d65b364c795344e6fbbfae807387e657b917/src/client/state/cookie-state-storage.ts#L40)

Domain to scope the cookie to, e.g. `example.com` so `a.example.com` and
`b.example.com` share one sign-in.

Must be the current host or a domain above it: the browser rejects a cookie
scoped to anything else, including a sibling subdomain, and refuses a public
suffix — so an over-broad value fails rather than leaking to unrelated sites.
Nothing needs to be served at the domain; it is only a scope.
