---
title: NotificationsUnsupportedError
editUrl: false
next: true
prev: true
---

Defined in: [src/client/notification-consent.ts:41](https://github.com/dfinity/icp-js-auth/blob/886a63c5466db4246e58babc5b6b759d2a0f2c12/src/client/notification-consent.ts#L41)

Thrown where the identity provider does not send notifications at all.

Its own error because its remedy is its own: there is nothing to retry and no
ceremony to run, so an application hides the control rather than reporting a
failure to the user. A deployment either carries the feature or does not.

## Extends

- `Error`

## Constructors

### Constructor

> **new NotificationsUnsupportedError**(`message?`): `NotificationsUnsupportedError`

Defined in: [src/client/notification-consent.ts:42](https://github.com/dfinity/icp-js-auth/blob/886a63c5466db4246e58babc5b6b759d2a0f2c12/src/client/notification-consent.ts#L42)

#### Parameters

##### message?

`string` = `'This Internet Identity does not send notifications'`

#### Returns

`NotificationsUnsupportedError`

#### Overrides

`Error.constructor`

## Properties

### cause?

> `optional` **cause?**: `unknown`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2022.error.d.ts:26

#### Inherited from

`Error.cause`

***

### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

#### Inherited from

`Error.message`

***

### name

> **name**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1076

#### Inherited from

`Error.name`

***

### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

#### Inherited from

`Error.stack`
