---
title: NotificationConsentOptions
editUrl: false
next: true
prev: true
---

Defined in: [src/client/notification-consent.ts:140](https://github.com/dfinity/icp-js-auth/blob/886a63c5466db4246e58babc5b6b759d2a0f2c12/src/client/notification-consent.ts#L140)

## Properties

### agentOptions?

> `optional` **agentOptions?**: `Omit`\<`HttpAgentOptions`, `"identity"`\>

Defined in: [src/client/notification-consent.ts:154](https://github.com/dfinity/icp-js-auth/blob/886a63c5466db4246e58babc5b6b759d2a0f2c12/src/client/notification-consent.ts#L154)

Options for the agent making them. `identity` is not among them: the agent
signs as the session, which is what both calls are authorised by.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [src/client/notification-consent.ts:148](https://github.com/dfinity/icp-js-auth/blob/886a63c5466db4246e58babc5b6b759d2a0f2c12/src/client/notification-consent.ts#L148)

The canister these calls go to.

***

### sessionChain

> **sessionChain**: `DelegationChain`

Defined in: [src/client/notification-consent.ts:145](https://github.com/dfinity/icp-js-auth/blob/886a63c5466db4246e58babc5b6b759d2a0f2c12/src/client/notification-consent.ts#L145)

The chain proving those calls come from the session. Restricted to II.

***

### sessionKey

> **sessionKey**: `SignIdentity`

Defined in: [src/client/notification-consent.ts:142](https://github.com/dfinity/icp-js-auth/blob/886a63c5466db4246e58babc5b6b759d2a0f2c12/src/client/notification-consent.ts#L142)

The key the session chain delegates to. Signs the calls made here.
