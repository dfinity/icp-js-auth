---
title: SignedAttributes
editUrl: false
next: true
prev: true
---

Defined in: [src/client/auth-client.ts:295](https://github.com/dfinity/icp-js-auth/blob/886a63c5466db4246e58babc5b6b759d2a0f2c12/src/client/auth-client.ts#L295)

## Properties

### data

> **data**: `Uint8Array`

Defined in: [src/client/auth-client.ts:296](https://github.com/dfinity/icp-js-auth/blob/886a63c5466db4246e58babc5b6b759d2a0f2c12/src/client/auth-client.ts#L296)

***

### signature

> **signature**: `Uint8Array`

Defined in: [src/client/auth-client.ts:297](https://github.com/dfinity/icp-js-auth/blob/886a63c5466db4246e58babc5b6b759d2a0f2c12/src/client/auth-client.ts#L297)
