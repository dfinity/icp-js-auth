---
title: NotificationConsentStatus
editUrl: false
next: true
prev: true
---

Defined in: [src/client/notification-consent.ts:30](https://github.com/dfinity/icp-js-auth/blob/886a63c5466db4246e58babc5b6b759d2a0f2c12/src/client/notification-consent.ts#L30)

Whether the user has allowed this application to notify them.

A record rather than a bare boolean, mirroring what the canister answers: a
second fact about the decision can then be reported without a breaking change
to anything that already reads `granted`.

## Properties

### granted

> **granted**: `boolean`

Defined in: [src/client/notification-consent.ts:31](https://github.com/dfinity/icp-js-auth/blob/886a63c5466db4246e58babc5b6b759d2a0f2c12/src/client/notification-consent.ts#L31)
