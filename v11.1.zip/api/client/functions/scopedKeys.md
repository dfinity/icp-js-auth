---
title: scopedKeys
editUrl: false
next: true
prev: true
---

## Call Signature

> **scopedKeys**\<`P`, `K`\>(`params`): `` `openid:${{ apple: "https://appleid.apple.com"; google: "https://accounts.google.com"; microsoft: "https://login.microsoftonline.com/{tid}/v2.0" }[P]}:${K}` ``[]

Defined in: [src/client/auth-client.ts:1862](https://github.com/dfinity/icp-js-auth/blob/886a63c5466db4246e58babc5b6b759d2a0f2c12/src/client/auth-client.ts#L1862)

Scopes attribute keys to an OpenID provider.

When using one-click sign-in, attributes can be scoped to the same provider
so the user grants access in a single step without an additional prompt.

### Type Parameters

#### P

`P` *extends* `"google"` \| `"apple"` \| `"microsoft"`

#### K

`K` *extends* `string` = `"name"` \| `"email"` \| `"verified_email"`

### Parameters

#### params

##### keys?

readonly `K`[]

The attribute keys to scope. Defaults to `['name', 'email', 'verified_email']`.

##### openIdProvider

`P`

The OpenID provider the keys should be scoped to.

##### ssoDomain?

`undefined`

### Returns

`` `openid:${{ apple: "https://appleid.apple.com"; google: "https://accounts.google.com"; microsoft: "https://login.microsoftonline.com/{tid}/v2.0" }[P]}:${K}` ``[]

The scoped attribute keys as `openid:<provider-url>:<key>`.

### Example

```ts
scopedKeys({ openIdProvider: 'google', keys: ['email'] });
// ['openid:https://accounts.google.com:email']
```

## Call Signature

> **scopedKeys**\<`D`, `K`\>(`params`): `` `sso:${Lowercase<D>}:${K}` ``[]

Defined in: [src/client/auth-client.ts:1885](https://github.com/dfinity/icp-js-auth/blob/886a63c5466db4246e58babc5b6b759d2a0f2c12/src/client/auth-client.ts#L1885)

Scopes attribute keys to an organization's SSO.

When using one-click SSO sign-in, attributes can be scoped to the same
organization so the user grants access in a single step.

### Type Parameters

#### D

`D` *extends* `string`

#### K

`K` *extends* `string` = `"name"` \| `"email"`

### Parameters

#### params

##### keys?

readonly `K`[]

The attribute keys to scope. Defaults to `['name', 'email']`;
  `verified_email` is not available for an organization SSO.

##### openIdProvider?

`undefined`

##### ssoDomain

`D`

The organization domain the keys should be scoped to.

### Returns

`` `sso:${Lowercase<D>}:${K}` ``[]

The scoped attribute keys as `sso:<domain>:<key>`.

### Example

```ts
scopedKeys({ ssoDomain: 'dfinity.org', keys: ['email'] });
// ['sso:dfinity.org:email']
```
