---
title: SessionNotHeldError
editUrl: false
next: true
prev: true
---

Defined in: [src/client/auth-client.ts:342](https://github.com/dfinity/icp-js-auth/blob/238494139615f055bc1c5d51a479b0005ed8546e/src/client/auth-client.ts#L342)

Thrown when a sign-in exists within the state store's reach but this origin
holds no credential for it.

A sibling subdomain reads the shared record on its first load and is in exactly
this position: someone is signed in, and it has nothing to act with until it
acquires its own. Catching this is where a silent re-issue belongs.

## Extends

- `Error`

## Constructors

### Constructor

> **new SessionNotHeldError**(`message?`): `SessionNotHeldError`

Defined in: [src/client/auth-client.ts:343](https://github.com/dfinity/icp-js-auth/blob/238494139615f055bc1c5d51a479b0005ed8546e/src/client/auth-client.ts#L343)

#### Parameters

##### message?

`string` = `'A sign-in exists for this domain, but this origin holds no credential for it'`

#### Returns

`SessionNotHeldError`

#### Overrides

`Error.constructor`

## Properties

### cause?

> `optional` **cause?**: `unknown`

Defined in: node\_modules/.pnpm/typescript@6.0.3/node\_modules/typescript/lib/lib.es2022.error.d.ts:24

#### Inherited from

`Error.cause`

***

### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@6.0.3/node\_modules/typescript/lib/lib.es5.d.ts:1075

#### Inherited from

`Error.message`

***

### name

> **name**: `string`

Defined in: node\_modules/.pnpm/typescript@6.0.3/node\_modules/typescript/lib/lib.es5.d.ts:1074

#### Inherited from

`Error.name`

***

### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@6.0.3/node\_modules/typescript/lib/lib.es5.d.ts:1076

#### Inherited from

`Error.stack`
