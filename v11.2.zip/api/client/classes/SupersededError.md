---
title: SupersededError
editUrl: false
next: true
prev: true
---

Defined in: [src/client/auth-client.ts:381](https://github.com/dfinity/icp-js-auth/blob/238494139615f055bc1c5d51a479b0005ed8546e/src/client/auth-client.ts#L381)

Thrown when a later sign-in or sign-out took over from this one.

Not a failure of the operation so much as a change of mind: an origin has one
signer window and one sign-in, so the newer intent is the one honoured, and
the earlier one reports this rather than writing what it had assembled. A
caller may usually ignore it — the user is getting what they asked for second.

## Extends

- `Error`

## Constructors

### Constructor

> **new SupersededError**(`message?`): `SupersededError`

Defined in: [src/client/auth-client.ts:382](https://github.com/dfinity/icp-js-auth/blob/238494139615f055bc1c5d51a479b0005ed8546e/src/client/auth-client.ts#L382)

#### Parameters

##### message?

`string` = `'A later sign-in or sign-out took over from this one'`

#### Returns

`SupersededError`

#### Overrides

`Error.constructor`

## Properties

### cause?

> `optional` **cause?**: `unknown`

Defined in: node\_modules/.pnpm/typescript@6.0.3/node\_modules/typescript/lib/lib.es2022.error.d.ts:24

#### Inherited from

`Error.cause`

***

### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@6.0.3/node\_modules/typescript/lib/lib.es5.d.ts:1075

#### Inherited from

`Error.message`

***

### name

> **name**: `string`

Defined in: node\_modules/.pnpm/typescript@6.0.3/node\_modules/typescript/lib/lib.es5.d.ts:1074

#### Inherited from

`Error.name`

***

### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@6.0.3/node\_modules/typescript/lib/lib.es5.d.ts:1076

#### Inherited from

`Error.stack`
