---
title: NotificationConsentStatus
editUrl: false
next: true
prev: true
---

Defined in: [src/client/notification-consent.ts:30](https://github.com/dfinity/icp-js-auth/blob/238494139615f055bc1c5d51a479b0005ed8546e/src/client/notification-consent.ts#L30)

Whether the user has allowed this application to notify them.

A record rather than a bare boolean, mirroring what the canister answers: a
second fact about the decision can then be reported without a breaking change
to anything that already reads `granted`.

## Properties

### granted

> **granted**: `boolean`

Defined in: [src/client/notification-consent.ts:31](https://github.com/dfinity/icp-js-auth/blob/238494139615f055bc1c5d51a479b0005ed8546e/src/client/notification-consent.ts#L31)
