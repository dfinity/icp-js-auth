---
title: NotificationConsentService
editUrl: false
next: true
prev: true
---

Defined in: [src/client/notification-consent.ts:98](https://github.com/dfinity/icp-js-auth/blob/238494139615f055bc1c5d51a479b0005ed8546e/src/client/notification-consent.ts#L98)

The two Internet Identity methods an application makes about its own consent.

## Methods

### app\_notification\_consent\_status()

> **app\_notification\_consent\_status**(): `Promise`\<`Result`\<\{ `is_granted`: `boolean`; \}\>\>

Defined in: [src/client/notification-consent.ts:99](https://github.com/dfinity/icp-js-auth/blob/238494139615f055bc1c5d51a479b0005ed8546e/src/client/notification-consent.ts#L99)

#### Returns

`Promise`\<`Result`\<\{ `is_granted`: `boolean`; \}\>\>

***

### app\_revoke\_notification\_consent()

> **app\_revoke\_notification\_consent**(): `Promise`\<`Result`\<`null`\>\>

Defined in: [src/client/notification-consent.ts:100](https://github.com/dfinity/icp-js-auth/blob/238494139615f055bc1c5d51a479b0005ed8546e/src/client/notification-consent.ts#L100)

#### Returns

`Promise`\<`Result`\<`null`\>\>
